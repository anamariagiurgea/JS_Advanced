

// Definire structura JSON în JS
const quizData = {
  q1: {
    question: "Which one is correct team name in NBA?",
    options: ["New York Bulls", "Los Angeles Kings", "Golden State Warrios", "Huston Rocket"],
    answer: "Huston Rocket"
  },
  q2: {
    question: "'Namaste' is a traditional greeting in which Asian language?",
    options: ["Hindi", "Mandarin", "Nepalese", "Thai"],
    answer: "Hindi"
  },
  q3: {
    question: "The Spree river flows through which major European capital city?",
    options: ["Berlin", "Paris", "Rome", "London"],
    answer: "Berlin"
  },
  q4: {
    question: "Which famous artist had both a 'Rose Period' and a 'Blue Period'?",
    options: ["Pablo Picasso", "Vincent van Gogh", "Salvador Dali", "Edgar Degas"],
    answer: "Pablo Picasso"
  }
};

const quizContainer = document.getElementById('quiz-container');
const savedAnswers = JSON.parse(localStorage.getItem('userAnswers')) || {};

// Validam structura datelor din quiz in consola+stilizare
if (quizData && Object.keys(quizData).length > 0) {
  console.log(
    "%c Structura quizului a fost validată cu succes! Numar întrebari: " + Object.keys(quizData).length,"color: green;");
} else {
  console.error(
    "%c Eroare: Structura quizului este goala!","color: red; font-weight: bold;");
}

function renderQuiz() {
  quizContainer.innerHTML = ''; // curatam continutul vechi

  for (const key in quizData) {
    const questionObj = quizData[key];
    const userAnswer = savedAnswers[key];

    // intrebarile
    const questionDiv = document.createElement('div');
    questionDiv.classList.add('question');

    const questionTitle = document.createElement('h3');
    questionTitle.textContent = questionObj.question;
    questionDiv.appendChild(questionTitle);

    questionObj.options.forEach(option => {
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = key;
      input.value = option;

      // bifam raspunsul salvat anterior
      if (userAnswer === option) {
        input.checked = true;
      }

      // salvam în localStorage
      input.addEventListener('change', () => {
        savedAnswers[key] = option;
        localStorage.setItem('userAnswers', JSON.stringify(savedAnswers));
      });

      label.appendChild(input);
      label.append(` ${option}`);
      questionDiv.appendChild(label);
    });

    quizContainer.appendChild(questionDiv);
  }
}

//gestionarea eventualelor erori aparute la randare
try {
  renderQuiz();
} catch (error) {
  console.error("Eroare la afisarea quizzului:", error);
  document.getElementById('quiz-container').innerHTML =
    "<p style='color:red;'>Eroare la încarcarea quizului. Va rugam reincercati.</p>";
}

console.log("%c Randarea quizzului s-a finalizat fara erori.", "color: blue;" );

//testare eroare intentionata
//function renderQuiz() {
  //throw new Error("Test eroare intentionata");
  //quizContainer.innerHTML = ''; 

//}